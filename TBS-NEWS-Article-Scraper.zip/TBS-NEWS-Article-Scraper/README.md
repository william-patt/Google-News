# TBS-NEWS-Article-Scraper

Used to add cards to Anki
